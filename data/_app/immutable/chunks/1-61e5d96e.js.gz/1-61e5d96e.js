import{default as t}from"../components/error.svelte-8f5f1df8.js";export{t as component};
