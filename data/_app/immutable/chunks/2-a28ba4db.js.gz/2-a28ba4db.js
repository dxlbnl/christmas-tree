import{default as t}from"../components/pages/_page.svelte-8f03fb2c.js";export{t as component};
