import{default as t}from"../components/pages/testing/_page.svelte-fc088547.js";export{t as component};
